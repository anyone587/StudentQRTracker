import type { Express, Request, Response } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertUserSchema, insertQrCodeSchema, insertStudentSchema, insertActivitySchema } from "@shared/schema";
import { z } from "zod";
import { randomBytes } from "crypto";
import session from "express-session";
import memorystore from "memorystore";

const MemoryStore = memorystore(session);

export async function registerRoutes(app: Express): Promise<Server> {
  // Set up session
  app.use(
    session({
      secret: process.env.SESSION_SECRET || "unique-qr-registration-secret",
      resave: false,
      saveUninitialized: false,
      store: new MemoryStore({
        checkPeriod: 86400000, // 24 hours
      }),
      cookie: {
        maxAge: 24 * 60 * 60 * 1000, // 24 hours
      },
    })
  );

  // Helper to check if user is authenticated
  const isAuthenticated = (req: Request, res: Response, next: Function) => {
    if (req.session.userId) {
      return next();
    }
    res.status(401).json({ message: "Unauthorized" });
  };

  // Authentication routes
  app.post("/api/auth/login", async (req, res) => {
    try {
      const { username, password } = req.body;
      
      if (!username || !password) {
        return res.status(400).json({ message: "Username and password are required" });
      }
      
      const user = await storage.getUserByUsername(username);
      
      if (!user || user.password !== password) {
        return res.status(401).json({ message: "Invalid credentials" });
      }
      
      req.session.userId = user.id;
      req.session.isHod = user.isHod;
      
      const { password: _, ...userWithoutPassword } = user;
      
      return res.status(200).json({
        message: "Login successful",
        user: userWithoutPassword
      });
    } catch (error) {
      console.error("Login error:", error);
      return res.status(500).json({ message: "Internal server error" });
    }
  });

  app.post("/api/auth/logout", (req, res) => {
    req.session.destroy((err) => {
      if (err) {
        return res.status(500).json({ message: "Failed to logout" });
      }
      
      res.clearCookie("connect.sid");
      return res.status(200).json({ message: "Logout successful" });
    });
  });

  app.get("/api/auth/me", async (req, res) => {
    if (!req.session.userId) {
      return res.status(401).json({ message: "Not authenticated" });
    }
    
    try {
      const user = await storage.getUser(req.session.userId);
      
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      
      const { password, ...userWithoutPassword } = user;
      
      return res.status(200).json({
        user: userWithoutPassword
      });
    } catch (error) {
      console.error("Auth me error:", error);
      return res.status(500).json({ message: "Internal server error" });
    }
  });

  // QR Code routes
  app.post("/api/qr-codes", isAuthenticated, async (req, res) => {
    try {
      console.log("QR code creation request:", req.body);
      
      // Logging the expiry date received
      console.log("Received expiry date:", req.body.expiryDate, "Type:", typeof req.body.expiryDate);
      
      // Let Zod handle the date conversion with our improved schema
      const qrCodeData = insertQrCodeSchema.parse({
        ...req.body,
        userId: req.session.userId,
        token: randomBytes(16).toString("hex"),
        isActive: true
      });
      
      const newQrCode = await storage.createQrCode(qrCodeData);
      
      // Log activity
      await storage.createActivity({
        activityType: "QR Code Generation",
        userId: req.session.userId,
        qrCodeId: newQrCode.id,
        department: newQrCode.department,
        details: `QR Code generated for ${newQrCode.department}/${newQrCode.course}/${newQrCode.semester}`,
        status: "Active"
      });
      
      return res.status(201).json({ qrCode: newQrCode });
    } catch (error) {
      if (error instanceof z.ZodError) {
        console.error("QR code validation error:", JSON.stringify(error.errors, null, 2));
        return res.status(400).json({ message: "Invalid data", errors: error.errors });
      }
      
      console.error("QR code creation error:", error);
      return res.status(500).json({ message: "Internal server error" });
    }
  });

  app.get("/api/qr-codes", isAuthenticated, async (req, res) => {
    try {
      const qrCodes = await storage.getQrCodesByUserId(req.session.userId);
      return res.status(200).json({ qrCodes });
    } catch (error) {
      console.error("QR codes fetch error:", error);
      return res.status(500).json({ message: "Internal server error" });
    }
  });

  app.get("/api/qr-codes/:token", async (req, res) => {
    try {
      const { token } = req.params;
      const qrCode = await storage.getQrCodeByToken(token);
      
      if (!qrCode) {
        return res.status(404).json({ message: "QR code not found" });
      }
      
      if (!qrCode.isActive) {
        return res.status(400).json({ message: "QR code is inactive" });
      }
      
      const now = new Date();
      if (qrCode.expiryDate < now) {
        return res.status(400).json({ message: "QR code has expired" });
      }
      
      return res.status(200).json({ qrCode });
    } catch (error) {
      console.error("QR code fetch error:", error);
      return res.status(500).json({ message: "Internal server error" });
    }
  });

  // Student registration routes
  app.post("/api/students", async (req, res) => {
    try {
      const { qrToken, ...studentData } = req.body;
      
      if (!qrToken) {
        return res.status(400).json({ message: "QR token is required" });
      }
      
      const qrCode = await storage.getQrCodeByToken(qrToken);
      
      if (!qrCode) {
        return res.status(404).json({ message: "Invalid QR code" });
      }
      
      if (!qrCode.isActive) {
        return res.status(400).json({ message: "QR code is inactive" });
      }
      
      const now = new Date();
      if (qrCode.expiryDate < now) {
        return res.status(400).json({ message: "QR code has expired" });
      }
      
      const parsedStudentData = insertStudentSchema.parse({
        ...studentData,
        qrCodeId: qrCode.id
      });
      
      const newStudent = await storage.createStudent(parsedStudentData);
      
      // Log activity
      await storage.createActivity({
        activityType: "Student Registration",
        studentId: newStudent.id,
        qrCodeId: qrCode.id,
        department: qrCode.department,
        details: `Student ${newStudent.firstName} ${newStudent.lastName} registered using QR code`,
        status: "Complete"
      });
      
      return res.status(201).json({ 
        message: "Registration successful",
        student: newStudent 
      });
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid data", errors: error.errors });
      }
      
      console.error("Student registration error:", error);
      return res.status(500).json({ message: "Internal server error" });
    }
  });

  app.get("/api/students", isAuthenticated, async (req, res) => {
    try {
      const qrCodes = await storage.getQrCodesByUserId(req.session.userId);
      const qrCodeIds = qrCodes.map(qr => qr.id);
      
      let allStudents = [];
      for (const qrCodeId of qrCodeIds) {
        const students = await storage.getStudentsByQrCodeId(qrCodeId);
        allStudents = [...allStudents, ...students];
      }
      
      return res.status(200).json({ students: allStudents });
    } catch (error) {
      console.error("Students fetch error:", error);
      return res.status(500).json({ message: "Internal server error" });
    }
  });

  // Activity routes
  app.get("/api/activities", isAuthenticated, async (req, res) => {
    try {
      const limit = req.query.limit ? parseInt(req.query.limit as string) : undefined;
      const activities = await storage.getActivities(limit);
      return res.status(200).json({ activities });
    } catch (error) {
      console.error("Activities fetch error:", error);
      return res.status(500).json({ message: "Internal server error" });
    }
  });

  // Dashboard stats
  app.get("/api/dashboard/stats", isAuthenticated, async (req, res) => {
    try {
      // Get all QR codes for the user
      const qrCodes = await storage.getQrCodesByUserId(req.session.userId);
      
      // Get active QR codes
      const now = new Date();
      const activeQrCodes = qrCodes.filter(qr => qr.isActive && qr.expiryDate > now);
      
      // Get students for all QR codes
      let totalStudents = 0;
      let pendingCount = 0;
      
      for (const qrCode of qrCodes) {
        const students = await storage.getStudentsByQrCodeId(qrCode.id);
        totalStudents += students.length;
      }
      
      // Get unique departments
      const uniqueDepartments = [...new Set(qrCodes.map(qr => qr.department))];
      
      return res.status(200).json({
        stats: {
          activeQrCodes: activeQrCodes.length,
          registeredStudents: totalStudents,
          pendingRegistrations: pendingCount,
          departments: uniqueDepartments.length
        }
      });
    } catch (error) {
      console.error("Dashboard stats error:", error);
      return res.status(500).json({ message: "Internal server error" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
