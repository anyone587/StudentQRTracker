import { 
  users, 
  qrCodes, 
  students, 
  activities, 
  type User, 
  type InsertUser,
  type QrCode,
  type InsertQrCode,
  type Student,
  type InsertStudent,
  type Activity,
  type InsertActivity
} from "@shared/schema";

export interface IStorage {
  // User methods
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  // QR Code methods
  createQrCode(qrCode: InsertQrCode): Promise<QrCode>;
  getQrCode(id: number): Promise<QrCode | undefined>;
  getQrCodeByToken(token: string): Promise<QrCode | undefined>;
  getQrCodesByUserId(userId: number): Promise<QrCode[]>;
  
  // Student methods
  createStudent(student: InsertStudent): Promise<Student>;
  getStudent(id: number): Promise<Student | undefined>;
  getStudentsByQrCodeId(qrCodeId: number): Promise<Student[]>;
  
  // Activity methods
  createActivity(activity: InsertActivity): Promise<Activity>;
  getActivities(limit?: number): Promise<Activity[]>;
  getActivitiesByUserId(userId: number, limit?: number): Promise<Activity[]>;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private qrCodes: Map<number, QrCode>;
  private students: Map<number, Student>;
  private activities: Map<number, Activity>;
  
  private userCurrentId: number;
  private qrCodeCurrentId: number;
  private studentCurrentId: number;
  private activityCurrentId: number;

  constructor() {
    this.users = new Map();
    this.qrCodes = new Map();
    this.students = new Map();
    this.activities = new Map();
    
    this.userCurrentId = 1;
    this.qrCodeCurrentId = 1;
    this.studentCurrentId = 1;
    this.activityCurrentId = 1;

    // Add default admin user
    this.createUser({
      username: "admin",
      password: "admin123",
      fullName: "Administrator",
      department: "Computer Science",
      isHod: true
    });
  }

  // User methods
  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.userCurrentId++;
    const user: User = { ...insertUser, id };
    this.users.set(id, user);
    return user;
  }

  // QR Code methods
  async createQrCode(insertQrCode: InsertQrCode): Promise<QrCode> {
    const id = this.qrCodeCurrentId++;
    const now = new Date();
    const qrCode: QrCode = { 
      ...insertQrCode, 
      id, 
      createdAt: now
    };
    this.qrCodes.set(id, qrCode);
    return qrCode;
  }

  async getQrCode(id: number): Promise<QrCode | undefined> {
    return this.qrCodes.get(id);
  }

  async getQrCodeByToken(token: string): Promise<QrCode | undefined> {
    return Array.from(this.qrCodes.values()).find(
      (qrCode) => qrCode.token === token,
    );
  }

  async getQrCodesByUserId(userId: number): Promise<QrCode[]> {
    return Array.from(this.qrCodes.values()).filter(
      (qrCode) => qrCode.userId === userId,
    );
  }

  // Student methods
  async createStudent(insertStudent: InsertStudent): Promise<Student> {
    const id = this.studentCurrentId++;
    const now = new Date();
    const student: Student = { 
      ...insertStudent, 
      id, 
      registeredAt: now 
    };
    this.students.set(id, student);
    return student;
  }

  async getStudent(id: number): Promise<Student | undefined> {
    return this.students.get(id);
  }

  async getStudentsByQrCodeId(qrCodeId: number): Promise<Student[]> {
    return Array.from(this.students.values()).filter(
      (student) => student.qrCodeId === qrCodeId,
    );
  }

  // Activity methods
  async createActivity(insertActivity: InsertActivity): Promise<Activity> {
    const id = this.activityCurrentId++;
    const now = new Date();
    const activity: Activity = { 
      ...insertActivity, 
      id, 
      timestamp: now 
    };
    this.activities.set(id, activity);
    return activity;
  }

  async getActivities(limit?: number): Promise<Activity[]> {
    const allActivities = Array.from(this.activities.values())
      .sort((a, b) => b.timestamp.getTime() - a.timestamp.getTime());
    
    if (limit) {
      return allActivities.slice(0, limit);
    }
    
    return allActivities;
  }

  async getActivitiesByUserId(userId: number, limit?: number): Promise<Activity[]> {
    const userActivities = Array.from(this.activities.values())
      .filter((activity) => activity.userId === userId)
      .sort((a, b) => b.timestamp.getTime() - a.timestamp.getTime());
    
    if (limit) {
      return userActivities.slice(0, limit);
    }
    
    return userActivities;
  }
}

export const storage = new MemStorage();
