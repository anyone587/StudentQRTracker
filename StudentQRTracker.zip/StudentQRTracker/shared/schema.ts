import { pgTable, text, serial, integer, boolean, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// User (HOD) schema
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  fullName: text("full_name").notNull(),
  department: text("department").notNull(),
  isHod: boolean("is_hod").notNull().default(true),
});

// QR Code schema
export const qrCodes = pgTable("qr_codes", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  department: text("department").notNull(),
  course: text("course").notNull(),
  semester: text("semester").notNull(),
  expiryDate: timestamp("expiry_date").notNull(),
  createdAt: timestamp("created_at").notNull().defaultNow(),
  token: text("token").notNull().unique(),
  isActive: boolean("is_active").notNull().default(true),
});

// Student schema
export const students = pgTable("students", {
  id: serial("id").primaryKey(),
  qrCodeId: integer("qr_code_id").notNull(),
  firstName: text("first_name").notNull(),
  lastName: text("last_name").notNull(),
  email: text("email").notNull().unique(),
  rollNumber: text("roll_number").notNull().unique(),
  mobile: text("mobile").notNull(),
  dateOfBirth: text("date_of_birth").notNull(),
  previousQualification: text("previous_qualification").notNull(),
  previousSchool: text("previous_school").notNull(),
  percentage: text("percentage").notNull(),
  registeredAt: timestamp("registered_at").notNull().defaultNow(),
});

// Activity schema
export const activities = pgTable("activities", {
  id: serial("id").primaryKey(),
  activityType: text("activity_type").notNull(),
  userId: integer("user_id"),
  studentId: integer("student_id"),
  qrCodeId: integer("qr_code_id"),
  department: text("department").notNull(),
  timestamp: timestamp("timestamp").notNull().defaultNow(),
  details: text("details"),
  status: text("status").notNull(),
});

// Insert schemas
export const insertUserSchema = createInsertSchema(users).omit({
  id: true,
});

// Customize the QR code schema to handle dates better
export const insertQrCodeSchema = createInsertSchema(qrCodes)
  .extend({
    // Accept both string and Date types for expiryDate
    expiryDate: z.union([
      z.string().transform(val => new Date(val)),
      z.date()
    ])
  })
  .omit({
    id: true,
    createdAt: true,
  });

export const insertStudentSchema = createInsertSchema(students).omit({
  id: true,
  registeredAt: true,
});

export const insertActivitySchema = createInsertSchema(activities).omit({
  id: true,
  timestamp: true,
});

// Types
export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;

export type InsertQrCode = z.infer<typeof insertQrCodeSchema>;
export type QrCode = typeof qrCodes.$inferSelect;

export type InsertStudent = z.infer<typeof insertStudentSchema>;
export type Student = typeof students.$inferSelect;

export type InsertActivity = z.infer<typeof insertActivitySchema>;
export type Activity = typeof activities.$inferSelect;
