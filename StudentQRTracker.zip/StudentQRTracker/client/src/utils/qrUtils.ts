import { v4 as uuidv4 } from 'uuid';

/**
 * Generate a unique token for QR code registration
 */
export function generateQRToken(): string {
  return uuidv4();
}

/**
 * Generate a full registration URL from a token
 */
export function getRegistrationUrl(token: string): string {
  return `${window.location.origin}/register/${token}`;
}

/**
 * Create a sharable message with registration link
 */
export function createShareableMessage(department: string, course: string, semester: string, url: string): string {
  return `Please register for ${department} - ${course} - ${semester} using this link: ${url}`;
}

/**
 * Check if QR code is expired
 */
export function isQRCodeExpired(expiryDate: Date): boolean {
  const now = new Date();
  return now > new Date(expiryDate);
}
