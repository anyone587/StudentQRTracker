import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useLocation } from "wouter";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { QrCode, ArrowLeft, Download, Share, Loader2 } from "lucide-react";
import { z } from "zod";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { Card, CardContent } from "@/components/ui/card";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Button } from "@/components/ui/button";
import QRCodeDisplay from "@/components/qr/QRCodeDisplay";

const qrCodeSchema = z.object({
  department: z.string().min(1, "Department is required"),
  course: z.string().min(1, "Course is required"),
  semester: z.string().min(1, "Semester is required"),
  expiryDate: z.string().min(1, "Expiry date is required"),
});

type QRCodeForm = z.infer<typeof qrCodeSchema>;

export default function GenerateQR() {
  const { toast } = useToast();
  const [, navigate] = useLocation();
  const [qrCodeData, setQrCodeData] = useState<any>(null);
  const [showDistribution, setShowDistribution] = useState(false);

  const form = useForm<QRCodeForm>({
    resolver: zodResolver(qrCodeSchema),
    defaultValues: {
      department: "",
      course: "",
      semester: "",
      expiryDate: "",
    },
  });

  const generateQRMutation = useMutation({
    mutationFn: async (data: QRCodeForm) => {
      // Create a date object from the string, then convert to milliseconds for timestamp
      const expiryDate = new Date(data.expiryDate);
      console.log('Expiry date input:', data.expiryDate);
      console.log('Parsed expiry date:', expiryDate);
      
      // Set expiry to end of day (23:59:59)
      expiryDate.setHours(23, 59, 59, 999);
      
      // Convert the date to ISO string to fix the Date object serialization issue
      const res = await apiRequest("POST", "/api/qr-codes", {
        department: data.department,
        course: data.course,
        semester: data.semester,
        expiryDate: expiryDate.toISOString(),
      });
      return res.json();
    },
    onSuccess: (data) => {
      setQrCodeData(data.qrCode);
      setShowDistribution(true);
      toast({
        title: "QR Code Generated!",
        description: "The QR code has been successfully generated.",
      });
      
      // Invalidate dashboard stats
      queryClient.invalidateQueries({ queryKey: ['/api/dashboard/stats'] });
      queryClient.invalidateQueries({ queryKey: ['/api/activities'] });
    },
    onError: (error: Error) => {
      toast({
        title: "Failed to generate QR code",
        description: error.message || "An error occurred",
        variant: "destructive",
      });
    },
  });

  const onSubmit = (data: QRCodeForm) => {
    generateQRMutation.mutate(data);
  };

  const registrationUrl = qrCodeData 
    ? `${window.location.origin}/register/${qrCodeData.token}`
    : '';

  return (
    <div className="py-6">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="md:flex md:items-center md:justify-between">
          <div className="flex-1 min-w-0">
            <h1 className="text-2xl font-semibold text-gray-900">Generate QR Code</h1>
            <p className="mt-1 text-sm text-gray-500">Create and distribute QR codes for student registration</p>
          </div>
          <div className="mt-4 flex md:mt-0">
            <Button 
              variant="outline" 
              onClick={() => navigate('/')}
              className="ml-3 inline-flex items-center"
            >
              <ArrowLeft className="mr-2 -ml-1 h-4 w-4" />
              Back to Dashboard
            </Button>
          </div>
        </div>

        <div className="mt-6 grid grid-cols-1 gap-6 lg:grid-cols-2">
          {/* QR Generation Form */}
          <Card>
            <CardContent className="pt-6">
              <h3 className="text-lg leading-6 font-medium text-gray-900">Registration Details</h3>
              <Form {...form}>
                <form onSubmit={form.handleSubmit(onSubmit)} className="mt-5 space-y-4">
                  <FormField
                    control={form.control}
                    name="department"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Department</FormLabel>
                        <Select 
                          onValueChange={field.onChange} 
                          defaultValue={field.value}
                        >
                          <FormControl>
                            <SelectTrigger>
                              <SelectValue placeholder="Select a department" />
                            </SelectTrigger>
                          </FormControl>
                          <SelectContent>
                            <SelectItem value="Computer Science">Computer Science</SelectItem>
                            <SelectItem value="Electrical Engineering">Electrical Engineering</SelectItem>
                            <SelectItem value="Mechanical Engineering">Mechanical Engineering</SelectItem>
                            <SelectItem value="Civil Engineering">Civil Engineering</SelectItem>
                            <SelectItem value="Business Administration">Business Administration</SelectItem>
                            <SelectItem value="Physics">Physics</SelectItem>
                          </SelectContent>
                        </Select>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="course"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Course</FormLabel>
                        <Select 
                          onValueChange={field.onChange} 
                          defaultValue={field.value}
                        >
                          <FormControl>
                            <SelectTrigger>
                              <SelectValue placeholder="Select a course" />
                            </SelectTrigger>
                          </FormControl>
                          <SelectContent>
                            <SelectItem value="B.Tech">B.Tech</SelectItem>
                            <SelectItem value="M.Tech">M.Tech</SelectItem>
                            <SelectItem value="B.Sc">B.Sc</SelectItem>
                            <SelectItem value="M.Sc">M.Sc</SelectItem>
                            <SelectItem value="BBA">BBA</SelectItem>
                            <SelectItem value="MBA">MBA</SelectItem>
                          </SelectContent>
                        </Select>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="semester"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Semester</FormLabel>
                        <Select 
                          onValueChange={field.onChange} 
                          defaultValue={field.value}
                        >
                          <FormControl>
                            <SelectTrigger>
                              <SelectValue placeholder="Select semester" />
                            </SelectTrigger>
                          </FormControl>
                          <SelectContent>
                            <SelectItem value="1st Semester">1st Semester</SelectItem>
                            <SelectItem value="2nd Semester">2nd Semester</SelectItem>
                            <SelectItem value="3rd Semester">3rd Semester</SelectItem>
                            <SelectItem value="4th Semester">4th Semester</SelectItem>
                            <SelectItem value="5th Semester">5th Semester</SelectItem>
                            <SelectItem value="6th Semester">6th Semester</SelectItem>
                            <SelectItem value="7th Semester">7th Semester</SelectItem>
                            <SelectItem value="8th Semester">8th Semester</SelectItem>
                          </SelectContent>
                        </Select>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="expiryDate"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Expiry Date</FormLabel>
                        <FormControl>
                          <Input type="date" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <Button 
                    type="submit" 
                    className="w-full mt-3"
                    disabled={generateQRMutation.isPending}
                  >
                    {generateQRMutation.isPending ? (
                      <>
                        <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                        Generating...
                      </>
                    ) : (
                      <>
                        <QrCode className="mr-2 h-4 w-4" />
                        Generate QR Code
                      </>
                    )}
                  </Button>
                </form>
              </Form>
            </CardContent>
          </Card>

          {/* QR Display Area */}
          <Card>
            <CardContent className="pt-6 flex flex-col items-center justify-center min-h-[400px]">
              <QRCodeDisplay 
                isLoading={generateQRMutation.isPending}
                qrData={qrCodeData ? {
                  department: qrCodeData.department,
                  course: qrCodeData.course,
                  semester: qrCodeData.semester,
                  url: registrationUrl
                } : null}
              />
            </CardContent>
          </Card>
        </div>
        
        {/* Distribution Options Section */}
        {showDistribution && (
          <div className="mt-8">
            <h2 className="text-lg font-medium text-gray-900">Distribution Options</h2>
            <div className="mt-4 grid grid-cols-1 gap-4 sm:grid-cols-3">
              <Card>
                <CardContent className="pt-6">
                  <div className="text-center mb-2">
                    <div className="inline-flex items-center justify-center p-2 bg-primary-100 rounded-full text-primary">
                      <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-6 h-6">
                        <path strokeLinecap="round" strokeLinejoin="round" d="M21.75 6.75v10.5a2.25 2.25 0 01-2.25 2.25h-15a2.25 2.25 0 01-2.25-2.25V6.75m19.5 0A2.25 2.25 0 0019.5 4.5h-15a2.25 2.25 0 00-2.25 2.25m19.5 0v.243a2.25 2.25 0 01-1.07 1.916l-7.5 4.615a2.25 2.25 0 01-2.36 0L3.32 8.91a2.25 2.25 0 01-1.07-1.916V6.75" />
                      </svg>
                    </div>
                    <h3 className="mt-2 text-lg font-medium text-gray-900">Email to Students</h3>
                  </div>
                  <p className="text-sm text-gray-500 mb-4">Send QR code directly to student email addresses</p>
                  <Button className="w-full">
                    Send Email
                  </Button>
                </CardContent>
              </Card>
              
              <Card>
                <CardContent className="pt-6">
                  <div className="text-center mb-2">
                    <div className="inline-flex items-center justify-center p-2 bg-primary-100 rounded-full text-primary">
                      <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-6 h-6">
                        <path strokeLinecap="round" strokeLinejoin="round" d="M10.5 1.5H8.25A2.25 2.25 0 006 3.75v16.5a2.25 2.25 0 002.25 2.25h7.5A2.25 2.25 0 0018 20.25V3.75a2.25 2.25 0 00-2.25-2.25H13.5m-3 0V3h3V1.5m-3 0h3m-3 18.75h3" />
                      </svg>
                    </div>
                    <h3 className="mt-2 text-lg font-medium text-gray-900">SMS to Students</h3>
                  </div>
                  <p className="text-sm text-gray-500 mb-4">Send QR code link via SMS to student phone numbers</p>
                  <Button className="w-full">
                    Send SMS
                  </Button>
                </CardContent>
              </Card>
              
              <Card>
                <CardContent className="pt-6">
                  <div className="text-center mb-2">
                    <div className="inline-flex items-center justify-center p-2 bg-primary-100 rounded-full text-primary">
                      <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-6 h-6">
                        <path strokeLinecap="round" strokeLinejoin="round" d="M6.72 13.829c-.24.03-.48.062-.72.096m.72-.096a42.415 42.415 0 0110.56 0m-10.56 0L6.34 18m10.94-4.171c.24.03.48.062.72.096m-.72-.096L17.66 18m0 0l.229 2.523a1.125 1.125 0 01-1.12 1.227H7.231c-.662 0-1.18-.568-1.12-1.227L6.34 18m11.318 0h1.091A2.25 2.25 0 0021 15.75V9.456c0-1.081-.768-2.015-1.837-2.175a48.055 48.055 0 00-1.913-.247M6.34 18H5.25A2.25 2.25 0 013 15.75V9.456c0-1.081.768-2.015 1.837-2.175a48.041 48.041 0 011.913-.247m10.5 0a48.536 48.536 0 00-10.5 0m10.5 0V3.375c0-.621-.504-1.125-1.125-1.125h-8.25c-.621 0-1.125.504-1.125 1.125v3.659M18 10.5h.008v.008H18V10.5zm-3 0h.008v.008H15V10.5z" />
                      </svg>
                    </div>
                    <h3 className="mt-2 text-lg font-medium text-gray-900">Print QR Codes</h3>
                  </div>
                  <p className="text-sm text-gray-500 mb-4">Print QR codes for physical distribution</p>
                  <Button className="w-full">
                    Print QR
                  </Button>
                </CardContent>
              </Card>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
