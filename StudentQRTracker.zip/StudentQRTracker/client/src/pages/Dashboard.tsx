import { useState, useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { useLocation } from "wouter";
import { useToast } from "@/hooks/use-toast";
import { Loader2 } from "lucide-react";
import StatCard from "@/components/dashboard/StatCard";
import ActivityTable from "@/components/dashboard/ActivityTable";
import { Button } from "@/components/ui/button";
import { School, QrCode, UserPlus, FileText } from "lucide-react";
import { Activity } from "@shared/schema";

type DashboardStats = {
  activeQrCodes: number;
  registeredStudents: number;
  pendingRegistrations: number;
  departments: number;
};

export default function Dashboard() {
  const { toast } = useToast();
  const [, navigate] = useLocation();

  // Fetch dashboard stats
  const { data: statsData, isLoading: statsLoading } = useQuery<{stats: DashboardStats}>({
    queryKey: ['/api/dashboard/stats'],
  });
  
  // Fetch recent activities
  const { data: activitiesData, isLoading: activitiesLoading } = useQuery<{activities: Activity[]}>({
    queryKey: ['/api/activities?limit=5'],
  });

  if (statsLoading || activitiesLoading) {
    return (
      <div className="py-6 bg-gray-50 min-h-screen">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="bg-gradient-to-r from-primary/90 to-primary/70 rounded-lg shadow-md p-6 mb-8 animate-pulse">
            <div className="h-8 w-3/4 bg-white/20 rounded-md"></div>
            <div className="h-4 w-1/2 bg-white/20 rounded-md mt-2"></div>
          </div>
          
          <div className="mt-6 grid grid-cols-1 gap-5 sm:grid-cols-2 lg:grid-cols-4">
            {[...Array(4)].map((_, i) => (
              <div key={i} className="bg-white rounded-md shadow-sm overflow-hidden animate-pulse">
                <div className="h-1.5 bg-primary/50"></div>
                <div className="p-6">
                  <div className="flex items-center">
                    <div className="h-12 w-12 rounded-full bg-gray-200"></div>
                    <div className="ml-5 w-0 flex-1">
                      <div className="h-4 w-20 bg-gray-200 rounded"></div>
                      <div className="h-8 w-12 bg-gray-200 rounded mt-2"></div>
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
          
          <div className="mt-8 flex flex-col items-center justify-center">
            <Loader2 className="h-10 w-10 animate-spin text-primary" />
            <p className="mt-4 text-gray-600">Loading dashboard data...</p>
          </div>
        </div>
      </div>
    );
  }

  const stats: DashboardStats = statsData?.stats || {
    activeQrCodes: 0,
    registeredStudents: 0,
    pendingRegistrations: 0,
    departments: 0
  };

  const activities = activitiesData?.activities || [];

  return (
    <div className="py-6 bg-gray-50 min-h-screen">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="bg-gradient-to-r from-primary/90 to-primary rounded-lg shadow-md p-6 mb-8">
          <h1 className="text-3xl font-bold text-white">Welcome to UniQR Dashboard</h1>
          <p className="text-white/90 mt-2">Manage your student registrations with QR codes efficiently</p>
        </div>
        
        {/* Stats Overview */}
        <div className="mt-6 grid grid-cols-1 gap-5 sm:grid-cols-2 lg:grid-cols-4">
          <StatCard 
            icon={<QrCode className="h-6 w-6" />}
            title="Active QR Codes"
            value={stats.activeQrCodes}
            color="bg-primary/10 text-primary"
          />
          
          <StatCard 
            icon={<UserPlus className="h-6 w-6" />}
            title="Registered Students"
            value={stats.registeredStudents}
            color="bg-green-500/10 text-green-600"
          />
          
          <StatCard 
            icon={<Loader2 className="h-6 w-6" />}
            title="Pending Registrations"
            value={stats.pendingRegistrations}
            color="bg-amber-500/10 text-amber-600"
          />
          
          <StatCard 
            icon={<School className="h-6 w-6" />}
            title="Departments"
            value={stats.departments}
            color="bg-indigo-500/10 text-indigo-600"
          />
        </div>
        
        {/* Quick Actions Section */}
        <div className="mt-8 bg-white p-6 rounded-lg shadow-sm">
          <h2 className="text-xl font-semibold text-gray-900 border-b pb-2">Quick Actions</h2>
          <div className="mt-4 grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3">
            <Button 
              onClick={() => navigate('/generate-qr')}
              className="flex items-center justify-center bg-gradient-to-r from-primary to-primary/80 hover:from-primary/90 hover:to-primary"
              size="lg"
            >
              <QrCode className="mr-2 h-5 w-5" />
              Generate New QR Code
            </Button>
            
            <Button 
              variant="secondary"
              className="flex items-center justify-center"
              size="lg"
              onClick={() => navigate('/students')}
            >
              <UserPlus className="mr-2 h-5 w-5" />
              View Registered Students
            </Button>
            
            <Button 
              variant="outline"
              className="flex items-center justify-center"
              size="lg"
              onClick={() => navigate('/reports')}
            >
              <FileText className="mr-2 h-5 w-5" />
              Generate Reports
            </Button>
          </div>
        </div>
        
        {/* Recent Activity Section */}
        <div className="mt-8 bg-white p-6 rounded-lg shadow-sm">
          <h2 className="text-xl font-semibold text-gray-900 border-b pb-2">Recent Activity</h2>
          <ActivityTable activities={activities} />
        </div>
        
      </div>
    </div>
  );
}
