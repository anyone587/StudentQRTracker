import { Switch, Route, useLocation } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import NotFound from "@/pages/not-found";
import Dashboard from "@/pages/Dashboard";
import Login from "@/pages/Login";
import GenerateQR from "@/pages/GenerateQR";
import StudentRegistration from "@/pages/StudentRegistration";
import Navbar from "@/components/layout/Navbar";
import Footer from "@/components/layout/Footer";
import { useAuth } from "@/hooks/useAuth";
import { Loader2 } from "lucide-react";
import { useEffect } from "react";

function Router() {
  const [location, setLocation] = useLocation();
  const { user, isLoading, isAuthenticated } = useAuth();

  // For debugging
  useEffect(() => {
    console.log('Auth state changed:', { isAuthenticated, isLoading, location, user });
  }, [isAuthenticated, isLoading, location, user]);

  // Handle redirects based on authentication state
  useEffect(() => {
    if (isLoading) return; // Don't redirect while loading

    // Allow registration pages to be accessed without authentication
    const isRegistrationPage = location.startsWith("/register");
    const isLoginPage = location === "/login";
    
    // Redirect to login if not authenticated and not on allowed pages
    if (!isAuthenticated && !isRegistrationPage && !isLoginPage) {
      console.log('Redirecting to login page: not authenticated');
      setLocation("/login");
      return;
    }
    
    // Redirect to dashboard if authenticated and on login page
    if (isAuthenticated && isLoginPage) {
      console.log('Redirecting to dashboard: already authenticated');
      setLocation("/");
      return;
    }
  }, [isLoading, isAuthenticated, location, setLocation]);

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  return (
    <div className="min-h-screen flex flex-col">
      {isAuthenticated && <Navbar />}
      <main className="flex-grow">
        <Switch>
          <Route path="/login" component={Login} />
          <Route path="/" component={Dashboard} />
          <Route path="/generate-qr" component={GenerateQR} />
          <Route path="/register/:token" component={StudentRegistration} />
          <Route component={NotFound} />
        </Switch>
      </main>
      <Footer />
    </div>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <Router />
      <Toaster />
    </QueryClientProvider>
  );
}

export default App;
