import { Link } from "wouter";
import { HelpCircle, Mail, Shield } from "lucide-react";

export default function Footer() {
  const currentYear = new Date().getFullYear();

  return (
    <footer className="bg-white border-t border-gray-200 py-6">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="md:flex md:items-center md:justify-between">
          <div className="flex justify-center md:order-2">
            <p className="text-center text-sm text-gray-500">
              &copy; {currentYear} UniQR Registration System. All rights reserved.
            </p>
          </div>
          <div className="mt-4 md:mt-0 md:order-1 flex justify-center space-x-6">
            <Link href="/help" className="text-gray-400 hover:text-gray-500 flex items-center">
              <HelpCircle className="h-5 w-5" />
              <span className="sr-only">Help</span>
            </Link>
            <Link href="/contact" className="text-gray-400 hover:text-gray-500 flex items-center">
              <Mail className="h-5 w-5" />
              <span className="sr-only">Contact</span>
            </Link>
            <Link href="/privacy" className="text-gray-400 hover:text-gray-500 flex items-center">
              <Shield className="h-5 w-5" />
              <span className="sr-only">Privacy</span>
            </Link>
          </div>
        </div>
      </div>
    </footer>
  );
}
