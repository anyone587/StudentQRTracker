import { useEffect, useRef } from "react";
import { QrCode, Download, Share, Loader2 } from "lucide-react";
import { Button } from "@/components/ui/button";

interface QRDisplayProps {
  isLoading: boolean;
  qrData: {
    department: string;
    course: string;
    semester: string;
    url: string;
  } | null;
}

export default function QRCodeDisplay({ isLoading, qrData }: QRDisplayProps) {
  const qrRef = useRef<HTMLDivElement>(null);

  // Generate QR code when data is available
  useEffect(() => {
    if (qrData && qrRef.current) {
      // Use a dynamic import for QRCode library
      import('qrcode').then((QRCode) => {
        QRCode.toCanvas(
          qrRef.current,
          qrData.url,
          {
            width: 200,
            margin: 2,
            color: {
              dark: '#000',
              light: '#fff'
            }
          },
          (error) => {
            if (error) console.error('Error generating QR code:', error);
          }
        );
      });
    }
  }, [qrData]);

  // Function to download QR code
  const downloadQRCode = () => {
    if (qrRef.current) {
      const canvas = qrRef.current.querySelector('canvas');
      if (canvas) {
        const link = document.createElement('a');
        link.download = `qrcode-${qrData?.department}-${qrData?.course}-${qrData?.semester}.png`;
        link.href = canvas.toDataURL('image/png');
        link.click();
      }
    }
  };

  // Function to share QR code
  const shareQRCode = () => {
    if (qrData && navigator.share) {
      navigator.share({
        title: 'Registration QR Code',
        text: `QR Code for ${qrData.department} / ${qrData.course} / ${qrData.semester}`,
        url: qrData.url
      });
    } else {
      // Fallback for browsers that don't support Web Share API
      navigator.clipboard.writeText(qrData?.url || '');
      alert('QR code link copied to clipboard!');
    }
  };

  if (isLoading) {
    return (
      <div className="text-center">
        <div className="mx-auto h-20 w-20 text-gray-400">
          <Loader2 className="animate-spin h-16 w-16 text-primary" />
        </div>
        <h3 className="mt-2 text-sm font-medium text-gray-900">Generating QR Code</h3>
        <p className="mt-1 text-sm text-gray-500">Please wait while we generate your QR code...</p>
      </div>
    );
  }

  if (!qrData) {
    return (
      <div className="text-center">
        <div className="mx-auto h-20 w-20 text-gray-400">
          <QrCode className="h-20 w-20 text-gray-300" />
        </div>
        <h3 className="mt-2 text-sm font-medium text-gray-900">No QR code generated</h3>
        <p className="mt-1 text-sm text-gray-500">Fill out the form to generate a QR code for student registration.</p>
      </div>
    );
  }

  return (
    <div>
      <div className="text-center mb-4">
        <h3 className="text-lg font-medium text-gray-900">QR Code Generated</h3>
        <p className="text-sm text-gray-500">
          {qrData.department} / {qrData.course} / {qrData.semester}
        </p>
      </div>
      
      <div ref={qrRef} className="p-4 border border-gray-200 rounded-lg bg-white mb-4 flex justify-center">
        {/* Canvas will be inserted here by QRCode.toCanvas */}
      </div>
      
      <div className="flex justify-center space-x-2">
        <Button size="sm" onClick={downloadQRCode}>
          <Download className="mr-1 h-4 w-4" />
          Download
        </Button>
        <Button size="sm" variant="secondary" onClick={shareQRCode}>
          <Share className="mr-1 h-4 w-4" />
          Share
        </Button>
      </div>
    </div>
  );
}
