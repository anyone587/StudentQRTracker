import { formatDistanceToNow } from "date-fns";
import { Activity } from "@shared/schema";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { ClipboardList } from "lucide-react";

interface ActivityTableProps {
  activities: Activity[];
}

export default function ActivityTable({ activities }: ActivityTableProps) {
  // Function to determine badge color based on status
  const getBadgeClassName = (status: string) => {
    switch(status.toLowerCase()) {
      case 'active':
      case 'complete':
        return 'bg-green-100 text-green-800 border-green-200';
      case 'pending':
        return 'bg-amber-100 text-amber-800 border-amber-200';
      case 'inactive':
      case 'failed':
        return 'bg-red-100 text-red-800 border-red-200';
      default:
        return 'bg-gray-100 text-gray-800 border-gray-200';
    }
  };

  const getActivityUser = (activity: Activity) => {
    if (activity.activityType === 'Student Registration') {
      return {
        name: 'Student',
        role: 'Student'
      };
    } else {
      return {
        name: 'Department HOD',
        role: 'HOD'
      };
    }
  };

  // Format timestamp to relative time
  const formatTime = (timestamp: Date) => {
    return formatDistanceToNow(new Date(timestamp), { addSuffix: true });
  };

  if (activities.length === 0) {
    return (
      <div className="mt-4 flex flex-col items-center justify-center p-8 bg-gray-50 rounded-lg border border-dashed border-gray-300">
        <ClipboardList className="h-12 w-12 text-gray-400 mb-3" />
        <h3 className="text-lg font-medium text-gray-900">No Recent Activities</h3>
        <p className="text-gray-500 text-center mt-1">
          When you or your students perform actions in the system, they will appear here.
        </p>
      </div>
    );
  }

  return (
    <div className="mt-4 flex flex-col">
      <div className="overflow-x-auto">
        <div className="inline-block min-w-full align-middle">
          <div className="overflow-hidden rounded-lg border border-gray-200">
            <Table>
              <TableHeader>
                <TableRow className="bg-gray-50">
                  <TableHead className="py-3.5">Activity</TableHead>
                  <TableHead className="py-3.5">User</TableHead>
                  <TableHead className="py-3.5">Department</TableHead>
                  <TableHead className="py-3.5">Date & Time</TableHead>
                  <TableHead className="py-3.5">Status</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {activities.map((activity) => {
                  const user = getActivityUser(activity);
                  return (
                    <TableRow key={activity.id} className="hover:bg-gray-50 transition-colors">
                      <TableCell className="font-medium text-gray-900">
                        {activity.activityType}
                      </TableCell>
                      <TableCell>
                        <div className="font-medium text-gray-900">{user.name}</div>
                        <div className="text-sm text-gray-500">{user.role}</div>
                      </TableCell>
                      <TableCell className="text-gray-700">
                        {activity.department}
                      </TableCell>
                      <TableCell className="text-gray-700">
                        {formatTime(activity.timestamp)}
                      </TableCell>
                      <TableCell>
                        <Badge className={`font-medium ${getBadgeClassName(activity.status)}`}>
                          {activity.status}
                        </Badge>
                      </TableCell>
                    </TableRow>
                  );
                })}
              </TableBody>
            </Table>
          </div>
        </div>
      </div>
    </div>
  );
}
