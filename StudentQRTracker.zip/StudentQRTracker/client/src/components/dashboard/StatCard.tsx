import { ReactNode } from "react";
import { Card, CardContent } from "@/components/ui/card";

interface StatCardProps {
  icon: ReactNode;
  title: string;
  value: number;
  color: string;
}

export default function StatCard({ icon, title, value, color }: StatCardProps) {
  return (
    <Card className="overflow-hidden transition-all duration-200 hover:shadow-md">
      <div className="h-1.5 bg-gradient-to-r from-primary to-primary/70"></div>
      <CardContent className="p-6">
        <div className="flex items-center">
          <div className={`flex-shrink-0 ${color} rounded-full p-3`}>
            {icon}
          </div>
          <div className="ml-5 w-0 flex-1">
            <h3 className="text-sm font-medium text-gray-500 truncate mb-1">{title}</h3>
            <p className="text-3xl font-bold text-gray-900">{value}</p>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
