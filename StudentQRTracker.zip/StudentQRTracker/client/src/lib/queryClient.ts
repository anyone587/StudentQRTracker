import { QueryClient, QueryFunction } from "@tanstack/react-query";

async function throwIfResNotOk(res: Response) {
  if (!res.ok) {
    const text = (await res.text()) || res.statusText;
    throw new Error(`${res.status}: ${text}`);
  }
}

export async function apiRequest(
  method: string,
  url: string,
  data?: unknown | undefined,
): Promise<Response> {
  console.log(`API Request: ${method} ${url}`, data);
  
  const res = await fetch(url, {
    method,
    headers: data ? { "Content-Type": "application/json" } : {},
    body: data ? JSON.stringify(data) : undefined,
    credentials: "include",
  });

  console.log(`API Response: ${res.status} ${res.statusText}`);
  
  // Clone the response for logging
  const clone = res.clone();
  try {
    const text = await clone.text();
    console.log(`Response body:`, text);
  } catch (e) {
    console.error('Failed to log response body', e);
  }

  await throwIfResNotOk(res);
  return res;
}

type UnauthorizedBehavior = "returnNull" | "throw";
export const getQueryFn: <T>(options: {
  on401: UnauthorizedBehavior;
}) => QueryFunction<T> =
  ({ on401: unauthorizedBehavior }) =>
  async ({ queryKey }) => {
    console.log(`Query fetch: ${queryKey[0]}`);
    
    const res = await fetch(queryKey[0] as string, {
      credentials: "include",
    });

    console.log(`Query Response: ${res.status} ${res.statusText}`);
    
    if (unauthorizedBehavior === "returnNull" && res.status === 401) {
      console.log('Query returned null due to 401');
      return null;
    }

    // Clone the response for logging
    const clone = res.clone();
    try {
      const text = await clone.text();
      console.log(`Query response body:`, text);
      // Parse the text back to JSON
      return JSON.parse(text);
    } catch (e) {
      console.error('Failed to log/parse query response', e);
      await throwIfResNotOk(res);
      return await res.json();
    }
  };

export const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      queryFn: getQueryFn({ on401: "throw" }),
      refetchInterval: false,
      refetchOnWindowFocus: false,
      staleTime: Infinity,
      retry: false,
    },
    mutations: {
      retry: false,
    },
  },
});
