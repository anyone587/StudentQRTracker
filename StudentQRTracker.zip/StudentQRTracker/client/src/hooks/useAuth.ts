import { useState, useEffect } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { apiRequest, getQueryFn } from '@/lib/queryClient';

interface User {
  id: number;
  username: string;
  fullName: string;
  department: string;
  isHod: boolean;
}

interface UseAuthReturn {
  user: User | null;
  isLoading: boolean;
  isAuthenticated: boolean;
  login: (username: string, password: string) => Promise<void>;
  logout: () => void;
}

export function useAuth(): UseAuthReturn {
  const queryClient = useQueryClient();
  const [isAuthenticated, setIsAuthenticated] = useState(false);

  // Fetch the current user with custom error handling
  const { data, isLoading } = useQuery<{ user: User | null }>({
    queryKey: ['/api/auth/me'],
    queryFn: async ({ queryKey }) => {
      console.log(`Auth fetch: ${queryKey[0]}`);
      try {
        const res = await fetch(queryKey[0] as string, {
          credentials: "include",
        });
        
        console.log(`Auth response: ${res.status} ${res.statusText}`);
        
        if (res.status === 401) {
          console.log('Auth returned null due to 401');
          return null;
        }
        
        if (!res.ok) {
          throw new Error(`${res.status}: ${await res.text()}`);
        }
        
        return await res.json();
      } catch (error) {
        console.error('Auth fetch error:', error);
        return null;
      }
    },
    staleTime: 0, // Always refetch when needed
    retry: false,
  });

  // Check localStorage for saved authentication state
  useEffect(() => {
    const savedUserData = localStorage.getItem('auth_user');
    if (savedUserData) {
      try {
        const savedUser = JSON.parse(savedUserData);
        if (savedUser && savedUser.id) {
          console.log('Restoring auth state from localStorage:', savedUser);
          setIsAuthenticated(true);
        }
      } catch (e) {
        console.error('Error parsing saved auth data:', e);
        localStorage.removeItem('auth_user');
      }
    }
  }, []);
  
  // Set authenticated state based on data
  useEffect(() => {
    console.log('Auth data changed:', data);
    if (data && data.user) {
      setIsAuthenticated(true);
      // Update localStorage with the latest user data
      localStorage.setItem('auth_user', JSON.stringify(data.user));
    } else if (data === null) {
      // Only clear if we explicitly got null (not on initial undefined)
      setIsAuthenticated(false);
    }
  }, [data]);
  
  // Fix: Sometimes React Query sets data to a Response object with status 401
  useEffect(() => {
    if (data && 'status' in data && data.status === 401) {
      setIsAuthenticated(false);
      localStorage.removeItem('auth_user');
    }
  }, [data]);

  // Login mutation
  const loginMutation = useMutation({
    mutationFn: async ({ username, password }: { username: string; password: string }) => {
      console.log('Login attempt:', { username });
      try {
        // Use normal fetch to have more control over the request
        const res = await fetch('/api/auth/login', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ username, password }),
          credentials: 'include' // Important: this ensures cookies are sent
        });
        
        console.log(`Login response status: ${res.status} ${res.statusText}`);
        
        const data = await res.json();
        console.log('Login response data:', data);
        
        if (!res.ok) {
          throw new Error(data.message || 'Login failed');
        }
        
        // Extract the session cookie for debugging
        const cookies = document.cookie;
        console.log('Cookies after login:', cookies);
        
        return data;
      } catch (error) {
        console.error('Login error:', error);
        throw error;
      }
    },
    onSuccess: (data) => {
      console.log('Login mutation success:', data);
      // Force an immediate refetch of auth status
      queryClient.invalidateQueries({ queryKey: ['/api/auth/me'] });
      setIsAuthenticated(true);
      
      // Set a manual flag in localStorage as backup for authentication state
      localStorage.setItem('auth_user', JSON.stringify(data.user));
    },
    onError: (error) => {
      console.error('Login mutation error:', error);
    },
  });

  // Logout function
  const logout = () => {
    apiRequest('POST', '/api/auth/logout', {})
      .then(() => {
        queryClient.invalidateQueries({ queryKey: ['/api/auth/me'] });
        setIsAuthenticated(false);
      })
      .catch(console.error);
  };

  // Login function
  const login = async (username: string, password: string) => {
    await loginMutation.mutateAsync({ username, password });
  };

  return {
    user: data?.user || null,
    isLoading,
    isAuthenticated,
    login,
    logout,
  };
}
